from rest_framework.response import Response

def send_response(result, message):
    response = {
        'success': True,
        'data': result,
        'message': message,
    }
    return Response(response, status=200)

def send_error(error, error_messages=None, code=412):
    response = {
        'success': False,
        'message': error,
    }
    if error_messages:
        response['data'] = error_messages
    return Response(response, status=code)
