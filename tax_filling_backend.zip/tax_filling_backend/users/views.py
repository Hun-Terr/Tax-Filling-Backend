from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated, AllowAny, IsAdminUser
from rest_framework_simplejwt.tokens import RefreshToken
from .models import User
from .serializers import RegisterUserSerializer, UserSerializer
from tax_filling_backend.utils import send_response, send_error
from django.contrib.auth import authenticate

from documents.models import Document, RequiredDocument
from tax_fillings.models import TaxFiling
from documents.serializers import DocumentSerializer  # Serializer for Document model
from tax_fillings.serializers import TaxFilingSerializer  # Serializer for TaxFiling model

class TestListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        users = User.objects.all()
        serializer = UserSerializer(users, many=True)
        return send_response(serializer.data, "User list retrieved successfully")

class RegisterView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = RegisterUserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return send_response(None, "User registered successfully")
        return send_error("Validation Error", serializer.errors, status.HTTP_400_BAD_REQUEST)

class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = request.data.get('email')
        password = request.data.get('password')
        user = User.objects.filter(email=email).first()
        if user and user.check_password(password):
            refresh = RefreshToken.for_user(user)
            return send_response({
                'access': str(refresh.access_token),
            }, "Login successful")
        return send_error("Invalid credentials", None, status.HTTP_401_UNAUTHORIZED)

class UserListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if request.user.role != 'admin':
            return send_error({"error": "Access denied"}, None, status.HTTP_403_FORBIDDEN)

        users = User.objects.filter(role='user')
        user_data = []

        # Total number of mandatory required documents (assumed to be defined in RequiredDocument table)
        total_mandatory_documents = RequiredDocument.objects.filter(is_mandatory=True).count()

        for user in users:
            # Count of mandatory documents uploaded by the user
            uploaded_mandatory_documents = Document.objects.filter(user=user, required_document__is_mandatory=True).count()

            # Check if the user has a tax filing entry
            tax_filed = TaxFiling.objects.filter(user=user).exists()

            # Serialize user data with additional fields
            user_info = UserSerializer(user).data
            user_info['uploaded_mandatory_documents'] = uploaded_mandatory_documents
            user_info['total_mandatory_documents'] = total_mandatory_documents
            user_info['tax_filed'] = tax_filed

            user_data.append(user_info)

        return send_response(user_data, "User list retrieved successfully")

class GetUserView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, user_id):
        if request.user.role != 'admin':
            return send_error("Access denied", code=status.HTTP_403_FORBIDDEN)

        try:
            user = User.objects.get(id=user_id, role='user')
            serializer = UserSerializer(user)
            return send_response(serializer.data, "User retrieved successfully")
        except User.DoesNotExist:
            return send_error("User not found", code=status.HTTP_404_NOT_FOUND)

class GetUserFullProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, user_id):
        # Check if the requesting user has admin privileges
        if request.user.role != 'admin':
            return send_error("Access denied. Admins only.", code=status.HTTP_403_FORBIDDEN)

        # Retrieve user details
        try:
            user = User.objects.get(id=user_id, role='user')
            user_data = UserSerializer(user).data
        except User.DoesNotExist:
            return send_error("User not found", code=status.HTTP_404_NOT_FOUND)

        # Retrieve user documents, separated by status
        documents = Document.objects.filter(user_id=user_id)
        pending_docs = documents.filter(status="pending")
        rejected_docs = documents.filter(status="rejected")
        verified_docs = documents.filter(status="verified")

        pending_serializer = DocumentSerializer(pending_docs, many=True)
        rejected_serializer = DocumentSerializer(rejected_docs, many=True)
        verified_serializer = DocumentSerializer(verified_docs, many=True)

        documents_data = {
            "pending_documents": pending_serializer.data,
            "rejected_documents": rejected_serializer.data,
            "verified_documents": verified_serializer.data
        }

        # Retrieve tax filings for the user
        tax_filings = TaxFiling.objects.filter(user_id=user_id)
        tax_filings_data = TaxFilingSerializer(tax_filings, many=True).data

        # Structure the final response data
        response_data = {
            "user_details": user_data,
            "documents": documents_data,
            "tax_filings": tax_filings_data
        }

        return send_response(response_data, "User profile retrieved successfully")


class AdminLoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = request.data.get('email')
        password = request.data.get('password')
        user = authenticate(email=email, password=password)

        if user is None or user.role != 'admin':
            return send_error("Invalid credentials or unauthorized access", code=401)

        refresh = RefreshToken.for_user(user)
        return send_response(
            {
                "refresh": str(refresh),
                "access": str(refresh.access_token),
            },
            "Admin login successful"
        )

class GetAdminListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if request.user.role != 'admin':
            return send_error("Access denied", code=403)

        admins = User.objects.filter(role='admin')
        return send_response(UserSerializer(admins, many=True).data, "Admin list retrieved successfully")


class GetAdminView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, admin_id):
        if request.user.role != 'admin':
            return send_error("Access denied", code=status.HTTP_403_FORBIDDEN)

        try:
            admin = User.objects.get(id=admin_id, role='admin')
            serializer = UserSerializer(admin)
            return send_response(serializer.data, "Admin retrieved successfully")
        except User.DoesNotExist:
            return send_error("Admin not found", code=status.HTTP_404_NOT_FOUND)


class CreateAdminView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if request.user.role != 'admin':
            return send_error("Access denied", code=403)

        data = request.data
        if User.objects.filter(email=data['email']).exists():
            return send_error("Admin with this email already exists", code=409)

        admin_user = User(
            email=data['email'],
            first_name=data.get('first_name', ''),
            last_name=data.get('last_name', ''),
            role='admin'
        )
        admin_user.set_password(data['password'])
        admin_user.save()
        return send_response(UserSerializer(admin_user).data, "Admin created successfully")

class DeleteAdminView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request, admin_id):
        if request.user.role != 'admin':
            return send_error("Access denied", code=403)

        try:
            admin = User.objects.get(id=admin_id, role='admin')
            admin.delete()
            return send_response({}, "Admin deleted successfully")
        except User.DoesNotExist:
            return send_error("Admin not found", code=404)

