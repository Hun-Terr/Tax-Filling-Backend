from django.core.management.base import BaseCommand
from django.contrib.auth.hashers import make_password
from users.models import User

class Command(BaseCommand):
    help = 'Creates a default admin user if it does not exist'

    def handle(self, *args, **kwargs):
        email = "admin@gmail.com"
        password = "admin@123"

        if not User.objects.filter(email=email).exists():
            User.objects.create(
                email=email,
                password=make_password(password),
                first_name="Admin",
                last_name="User",
                phone_number="",
                address="",
                role="admin",
            )
            self.stdout.write(self.style.SUCCESS(f"Default admin user '{email}' created successfully."))
        else:
            self.stdout.write(self.style.WARNING(f"Admin user '{email}' already exists."))
