from django.urls import path
from .views import *

urlpatterns = [
    path('register', RegisterView.as_view(), name='register'),
    path('login', LoginView.as_view(), name='login'),
    path('admin/users', UserListView.as_view(), name='admin-user-list'),
    path('admin/user/<int:user_id>', GetUserView.as_view(), name='get-user'),
    path('admin/user/profile/<int:user_id>', GetUserFullProfileView.as_view(), name='get-user-profile'),
    path('admin/login', AdminLoginView.as_view(), name='admin-login'),
    path('get_admin/<int:admin_id>', GetAdminView.as_view(), name='get-admin'),
    path('admin/create', CreateAdminView.as_view(), name='create-admin'),
    path('admin/delete/<int:admin_id>', DeleteAdminView.as_view(), name='delete-admin'),
    path('admin/list/', GetAdminListView.as_view(), name='get-admin-list'),

    #test
    path('test',TestListView.as_view(), name='testing'),
]