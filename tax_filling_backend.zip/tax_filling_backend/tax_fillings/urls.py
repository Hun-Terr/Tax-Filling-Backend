from django.urls import path
from .views import AdminCreateTaxFilingView, AdminRetrieveUpdateDeleteTaxFilingView, UserTaxFilingView

urlpatterns = [
    path('admin/create-tax-filing/<int:user_id>', AdminCreateTaxFilingView.as_view(), name='admin-create-tax-filing'),
    path('admin/tax-filing/<int:user_id>', AdminRetrieveUpdateDeleteTaxFilingView.as_view(), name='admin-retrieve-tax-filing'),
    path('admin/tax-filing/<int:tax_filing_id>/update-delete', AdminRetrieveUpdateDeleteTaxFilingView.as_view(), name='admin-update-delete-tax-filing'),
    path('user/tax-filing', UserTaxFilingView.as_view(), name='user-tax-filing'),
]
