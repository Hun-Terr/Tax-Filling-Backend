from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status as http_status
from .models import TaxFiling
from .serializers import TaxFilingCreateSerializer, TaxFilingSerializer
from documents.models import Document, RequiredDocument
from tax_filling_backend.utils import send_response, send_error

# Define allowed values for fields
ALLOWED_FILING_TYPES = ["state", "federal"]
ALLOWED_STATUS_VALUES = ["inprogress", "rejected", "completed"]


# Helper function to check if all required documents are uploaded and verified
def all_documents_verified(user_id):
    required_docs = RequiredDocument.objects.filter(is_mandatory=True)
    uploaded_verified_docs = Document.objects.filter(user_id=user_id, status="verified")
    uploaded_verified_doc_ids = uploaded_verified_docs.values_list("required_document_id", flat=True)
    pending_docs = required_docs.exclude(id__in=uploaded_verified_doc_ids)
    if pending_docs.exists():
        return False, "User has pending mandatory documents or unverified documents."
    return True, ""

# 1. Admin: Create Tax Filing Entry
class AdminCreateTaxFilingView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, user_id):
        # Ensure that the request is made by an admin
        if request.user.role != "admin":
            return send_error("Access denied. Admins only.", code=403)

        # Validate allowed values for filing_type
        filing_type = request.data.get("filing_type")
        if filing_type not in ALLOWED_FILING_TYPES:
            return send_error(f"Invalid filing type. Allowed values are: {', '.join(ALLOWED_FILING_TYPES)}", code=400)

        # Check if all required documents are uploaded and verified
        all_verified, reason = all_documents_verified(user_id)
        if not all_verified:
            return send_error(reason, code=400)

        # Proceed to create the TaxFiling entry
        serializer = TaxFilingCreateSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            serializer.save(user_id=user_id)
            return send_response(serializer.data, "Tax filing entry created successfully")
        return send_error("Failed to create tax filing entry", serializer.errors)

# 2. Admin: Retrieve, Update, Delete Tax Filing Entry
class AdminRetrieveUpdateDeleteTaxFilingView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, user_id):
        # Ensure the request is made by an admin
        if request.user.role != "admin":
            return send_error("Access denied. Admins only.", code=403)

        tax_filing = TaxFiling.objects.filter(user_id=user_id)
        if not tax_filing.exists():
            return send_error("No tax filing entry found for this user", code=404)

        serializer = TaxFilingSerializer(tax_filing, many=True)
        return send_response(serializer.data, "Tax filing entries retrieved successfully")

    def put(self, request, tax_filing_id):
        # Ensure the request is made by an admin
        if request.user.role != "admin":
            return send_error("Access denied. Admins only.", code=403)

        # Retrieve the document by its ID
        try:
            tax_filing = TaxFiling.objects.get(id=tax_filing_id)
        except TaxFiling.DoesNotExist:
            return send_error("Tax filing entry not found", code=404)

        # Validate allowed values for filing_type and status if they are in the request data
        filing_type = request.data.get("filing_type")
        status = request.data.get("status")

        if filing_type and filing_type not in ALLOWED_FILING_TYPES:
            return send_error(f"Invalid filing type. Allowed values are: {', '.join(ALLOWED_FILING_TYPES)}", code=400)

        if status and status not in ALLOWED_STATUS_VALUES:
            return send_error(f"Invalid status. Allowed values are: {', '.join(ALLOWED_STATUS_VALUES)}", code=400)

        # Update the document's status and review comment
        serializer = TaxFilingSerializer(tax_filing, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return send_response(serializer.data, "Tax filing entry updated successfully")
        return send_error("Failed to update tax filing entry", serializer.errors)

    def delete(self, request, tax_filing_id):
        # Ensure the request is made by an admin
        if request.user.role != "admin":
            return send_error("Access denied. Admins only.", code=403)

        try:
            tax_filing = TaxFiling.objects.get(id=tax_filing_id)
            tax_filing.delete()
            return send_response({}, "Tax filing entry deleted successfully")
        except TaxFiling.DoesNotExist:
            return send_error("Tax filing entry not found", code=404)


# 3. User: View Own Tax Filing Entry
class UserTaxFilingView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user_id = request.user.id

        # Check if the user has all documents uploaded and verified
        all_verified, reason = all_documents_verified(user_id)
        if not all_verified:
            return send_error(reason, code=400)

        # Retrieve the tax filing entry for the user
        tax_filing = TaxFiling.objects.filter(user_id=user_id)
        if not tax_filing.exists():
            return send_error("No tax filing entry found", code=404)

        serializer = TaxFilingSerializer(tax_filing, many=True)
        return send_response(serializer.data, "Tax filing entries retrieved successfully")
