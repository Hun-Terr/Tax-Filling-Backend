from rest_framework import serializers
from .models import TaxFiling


class TaxFilingCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxFiling
        fields = ['filing_type', 'state_code', 'filing_year']

    def create(self, validated_data):
        # Set reviewed_by as the admin creating the entry
        validated_data['reviewed_by'] = self.context['request'].user
        return super().create(validated_data)


class TaxFilingSerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxFiling
        fields = '__all__'
