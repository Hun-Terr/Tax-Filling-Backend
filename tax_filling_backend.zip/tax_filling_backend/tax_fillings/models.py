from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone

User = get_user_model()

class TaxFiling(models.Model):
    FILING_TYPES = [
        ("state", "State"),
        ("federal", "Federal"),
    ]

    STATUS_CHOICES = [
        ("inprogress", "In Progress"),
        ("rejected", "Rejected"),
        ("completed", "Completed"),
    ]

    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="filings")
    filing_type = models.CharField(max_length=20, choices=FILING_TYPES)
    state_code = models.CharField(max_length=5, blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="inprogress")
    filing_year = models.CharField(max_length=4)
    filed_at = models.DateTimeField(blank=True, null=True)
    reviewed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="reviews")
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Filing {self.id} - {self.filing_type} ({self.status})"
