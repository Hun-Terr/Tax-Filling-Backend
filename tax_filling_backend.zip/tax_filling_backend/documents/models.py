from django.db import models
from django.utils import timezone
from django.contrib.auth import get_user_model
import os

class RequiredDocument(models.Model):
    document_type = models.CharField(max_length=100)
    description = models.TextField()
    is_mandatory = models.BooleanField(default=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.document_type

User = get_user_model()

# Define a custom file path for uploaded documents
def user_directory_path(instance, filename):
    # Append user_id to filename and store in "uploads/documents/"
    base, ext = os.path.splitext(filename)
    new_filename = f"{base}_{instance.user.id}{ext}"
    return f"uploads/documents/{new_filename}"

class Document(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    filing_id = models.UUIDField(null=True, blank=True)
    required_document = models.ForeignKey(RequiredDocument, on_delete=models.SET_NULL, null=True, blank=True)
    document_type = models.CharField(max_length=100)
    file_path = models.FileField(upload_to=user_directory_path, default='null')
    uploaded_at = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=20, choices=[("pending", "Pending"), ("rejected", "Rejected"), ("verified", "Verified")], default="pending")
    review_comment = models.TextField(blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.document_type} - {self.user.email}"