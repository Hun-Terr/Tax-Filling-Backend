from django.urls import path
from .views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/required-documents', RequiredDocumentListView.as_view(), name='required-documents-list'),
    path('admin/required-documents/create', CreateRequiredDocumentView.as_view(), name='create-required-document'),
    path('admin/required-documents/edit/<int:document_id>', EditRequiredDocumentView.as_view(), name='edit-required-document'),
    path('admin/required-documents/delete/<int:document_id>', DeleteRequiredDocumentView.as_view(), name='delete-required-document'),

    path('user/documents', UserDocumentListView.as_view(), name='user-document-list'),
    path('user/documents/upload', UserDocumentUploadView.as_view(), name='user-document-upload'),

    path('admin/user-documents/<int:user_id>', AdminUserDocumentsView.as_view(), name='admin-user-documents'),
    path('admin/update-document-status/<int:document_id>', AdminUpdateDocumentStatusView.as_view(),
         name='admin-update-document-status'),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)