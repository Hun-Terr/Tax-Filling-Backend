from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from .models import RequiredDocument, Document
from .serializers import RequiredDocumentSerializer, DocumentSerializer, PendingRequiredDocumentSerializer
from tax_filling_backend.utils import send_response, send_error
from django.utils import timezone
from rest_framework.parsers import MultiPartParser, FormParser

# Helper function to check if the user is an admin
def is_admin(user):
    return user.is_authenticated and user.role == 'admin'

# 1. Get List of All Required Documents
class RequiredDocumentListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if not is_admin(request.user):
            return send_error("Access denied. Admins only.", code=403)

        required_documents = RequiredDocument.objects.all()
        serializer = RequiredDocumentSerializer(required_documents, many=True)
        return send_response(serializer.data, "List of all required documents")

# 2. Create a Required Document
class CreateRequiredDocumentView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if not is_admin(request.user):
            return send_error("Access denied. Admins only.", code=403)

        serializer = RequiredDocumentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return send_response(serializer.data, "Required document created successfully")
        return send_error("Failed to create required document", serializer.errors)

# 3. Edit a Required Document
class EditRequiredDocumentView(APIView):
    permission_classes = [IsAuthenticated]

    def put(self, request, document_id):
        if not is_admin(request.user):
            return send_error("Access denied. Admins only.", code=403)

        try:
            required_document = RequiredDocument.objects.get(id=document_id)
        except RequiredDocument.DoesNotExist:
            return send_error("Required document not found", code=404)

        serializer = RequiredDocumentSerializer(required_document, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return send_response(serializer.data, "Required document updated successfully")
        return send_error("Failed to update required document", serializer.errors)

# 4. Delete a Required Document
class DeleteRequiredDocumentView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request, document_id):
        if not is_admin(request.user):
            return send_error("Access denied. Admins only.", code=403)

        try:
            required_document = RequiredDocument.objects.get(id=document_id)
            required_document.delete()
            return send_response({}, "Required document deleted successfully")
        except RequiredDocument.DoesNotExist:
            return send_error("Required document not found", code=404)



class UserDocumentListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # Get all mandatory and optional required documents
        mandatory_docs = RequiredDocument.objects.filter(is_mandatory=True)
        optional_docs = RequiredDocument.objects.filter(is_mandatory=False)

        # Get uploaded documents for the user with a required_document_id set
        uploaded_docs = Document.objects.filter(user=request.user, status="verified")

        # Identify uploaded mandatory document IDs for this user
        uploaded_mandatory_doc_ids = uploaded_docs.filter(
            required_document__isnull=False
        ).values_list('required_document_id', flat=True)

        # Identify pending mandatory documents
        pending_mandatory_docs = mandatory_docs.exclude(id__in=uploaded_mandatory_doc_ids)

        # Serialize the data
        mandatory_serializer = PendingRequiredDocumentSerializer(
            pending_mandatory_docs, many=True, context={'user': request.user}
        )
        optional_serializer = RequiredDocumentSerializer(optional_docs, many=True)
        uploaded_serializer = DocumentSerializer(uploaded_docs, many=True)

        data = {
            "pending_mandatory_documents": mandatory_serializer.data,
            "optional_documents": optional_serializer.data,
            "uploaded_documents": uploaded_serializer.data
        }
        return send_response(data, "Document lists retrieved successfully")


class UserDocumentUploadView(APIView):
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]  # To handle file uploads

    def post(self, request):
        document_type = request.data.get('document_type')
        required_document_id = request.data.get('required_document_id')
        file = request.FILES.get('file')  # Access the uploaded file

        if not file:
            return send_error("No file provided", code=400)

        # Save the document with the user and file path
        document = Document(
            user=request.user,
            document_type=document_type,
            required_document_id=required_document_id,
            file_path=file,  # File is stored in 'file_path' field
            status="pending",
            uploaded_at=timezone.now()
        )
        document.save()

        return send_response(DocumentSerializer(document).data, "Document uploaded successfully")


# Define allowed status values
ALLOWED_STATUSES = ["pending", "rejected", "verified"]


class AdminUserDocumentsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, user_id):
        # Check if the requesting user has admin privileges
        if request.user.role != "admin":
            return send_error("Access denied. Admins only.", code=403)

        # Retrieve all documents uploaded by the specified user
        documents = Document.objects.filter(user_id=user_id)
        if not documents.exists():
            return send_error("No documents found for this user", code=404)

        # Filter documents by status
        pending_docs = documents.filter(status="pending")
        rejected_docs = documents.filter(status="rejected")
        verified_docs = documents.filter(status="verified")

        # Serialize each status category separately
        pending_serializer = DocumentSerializer(pending_docs, many=True)
        rejected_serializer = DocumentSerializer(rejected_docs, many=True)
        verified_serializer = DocumentSerializer(verified_docs, many=True)

        # Structure the response data
        data = {
            "pending_documents": pending_serializer.data,
            "rejected_documents": rejected_serializer.data,
            "verified_documents": verified_serializer.data
        }

        return send_response(data, "User documents retrieved successfully")


# 2. Update Document Status and Review Comment
class AdminUpdateDocumentStatusView(APIView):
    permission_classes = [IsAuthenticated]

    def put(self, request, document_id):
        # Check if the requesting user has admin privileges
        if request.user.role != "admin":
            return send_error("Access denied. Admins only.", code=403)

        # Retrieve the document by its ID
        try:
            document = Document.objects.get(id=document_id)
        except Document.DoesNotExist:
            return send_error("Document not found", code=404)

        # Get the new status and review comment from the request
        new_status = request.data.get("status")
        review_comment = request.data.get("review_comment")

        # Validate the new status
        if new_status not in ALLOWED_STATUSES:
            return send_error(f"Invalid status. Allowed values are: {', '.join(ALLOWED_STATUSES)}", code=400)

        # Update the document's status and review comment
        document.status = new_status
        if review_comment is not None:
            document.review_comment = review_comment
        document.save()

        # Serialize the updated document and return the response
        serializer = DocumentSerializer(document)
        return send_response(serializer.data, "Document status and comment updated successfully")