from rest_framework import serializers
from .models import RequiredDocument, Document

class RequiredDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = RequiredDocument
        fields = '__all__'

class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = '__all__'

class DocumentUploadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ('user', 'document_type', 'document_url', 'required_document')
        extra_kwargs = {
            'user': {'read_only': True}
        }


class PendingRequiredDocumentSerializer(serializers.ModelSerializer):
    # Nested serializer to include document status and comments if they exist
    associated_document = serializers.SerializerMethodField()

    class Meta:
        model = RequiredDocument
        fields = ['id', 'document_type', 'description', 'is_mandatory', 'associated_document']

    def get_associated_document(self, obj):
        user = self.context.get('user')
        document = Document.objects.filter(
            user=user,
            required_document=obj,
            status__in=["pending", "rejected"]
        ).first()

        if document:
            return {
                "status": document.status,
                "review_comment": document.review_comment
            }
        return None